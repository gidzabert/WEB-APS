<?php 
require_once("../includes/Config.php");
$stocks = new Stocks();
$login = new Login();
$db = $login->setDB($db);
$db = $stocks->setDB($db);

if (!isset($_SESSION['name'])){
  header('location: '.SITE_URL);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title><?php echo SITE_URL; ?></title>

  <!-- Bootstrap core CSS -->
  <link href="<?php echo SITE_URL;?>/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/simple-sidebar.css" rel="stylesheet">

</head>

<body>

      <nav class="navbar navbar-expand-lg navbar-light bg-dark border-bottom">
        <button class="btn btn-primary" id="menu-toggle">Menu</button>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <?php echo $_SESSION['name'];?>
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="#">Change Password</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#">logout</a>
              </div>
            </li>
          </ul>
        </div>
      </nav>

  <div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading m-2">Safe Stock </div>
      <div class="list-group list-group-flush">
        <a href="../StockAdmin" class="list-group-item list-group-item-action bg-light">Dashboard</a>
        <a href="Stock.php" class="list-group-item list-group-item-action bg-light">Stock--in</a>
      </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">

      <div class="container-fluid">
        <h1 class="mt-4 text-center">Receive Stock</h1>
        <div class="row">
          <div class="col-md-6">
            <div class="panel panel-default">
              <!-- /.panel-heading -->
              <div class="panel-body">
                  <?php
                    $stocks->getStockItems();
                  ?>
              </div>
              <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
          </div>
          <div class="col-md-6">
            <form method="POST" name="f1">
              <input name="source" value="<?php echo $_GET['source'];?>" type="hidden" />
              <input name="chk" value="" type="hidden" />
                <div class="form-group">
                  <label for="nome">Item Name</label>
                  <input type="text" class="form-control" id="item_name" name="item_name" placeholder="Item Name" required>
                </div>
                <div class="form-group">
                  <label for="nome">Quantities</label>
                  <input type="number" class="form-control" id="item_qty" name="item_qty" placeholder="Item Quantities" required>
                </div>
                <div class="form-group" style="margin-top:20px;">
                  <button type="submit" name="btnadd" class="btn btn-primary">Add Item</button>
                </div>
              </form>
        <?php
          if (isset($_POST['btnadd'])){
            if (empty($_POST['item_name']) or empty($_POST['item_qty'])){
              echo "Item Name or Quantity is required";
            }else{
              $type = 1;
              $stocks->ProcessStockIn($_POST['item_name'],$_POST['item_qty'],$_SESSION['name'],$type);
            }
          }

        ?>
          </div>
      </div>
    </div>
    <!-- /#page-content-wrapper -->

  </div>
  <!-- /#wrapper -->

  <!-- Bootstrap core JavaScript -->
  <script src="<?php echo SITE_URL;?>/assets/vendor/jquery/jquery.min.js"></script>
  <script src="<?php echo SITE_URL;?>/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Menu Toggle Script -->
    <script>
    $(document).ready(function(){
      $('[data-toggle="tooltip"]').tooltip();
    });
    </script>

</body>

</html>
