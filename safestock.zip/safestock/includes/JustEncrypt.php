<?php

class JustEncrypt {
     private $key = 'vDIa5JdknBqfrKOu8d7UpddnBMCH1vza'; //32 characters
     private $nonce = 'Ra5LeH7ntW2rvkz3dmqI5Stx'; //24 characters

     public function sodiumStaticEncrypt(string $data) {
           $encrypted = base64_encode(
                 sodium_crypto_secretbox(
                       $data,
                       $this->nonce,
                       $this->key
                 )
           );
           return $encrypted;
    }


     public function sodiumStaticDecrypt(string $data) {
           // decode the base64 on $data first
           $decrypt = base64_decode($data);
           $decrypted = sodium_crypto_secretbox_open($decrypt,$this->nonce,$this->key);
           return $decrypted;
     }
}

?>