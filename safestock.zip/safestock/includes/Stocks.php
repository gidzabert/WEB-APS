<?php

class Stocks{


    protected $db;
    protected $alert;

    public function setDB($db){
        $db = new DB();
        $alert = new Alerts();
        $this->db = $db;
        $this->alert = $alert;
    }
    
    public function ProcessStockIn($itemid,$qty,$user,$type) {
        $encrypt = new JustEncrypt();
        $date = date('r');
        try{
            switch($type){
                case 0:
                    Stocks::StockIO($itemid,$qty,$user,$type);
                    $total = Stocks::getAvailableQuantities($itemid) - $qty;
                    $hash_item = $encrypt->sodiumStaticEncrypt($itemid);
                    $hash_total = $encrypt->sodiumStaticEncrypt($total);
                    $hash_user = $encrypt->sodiumStaticEncrypt($user);

                    if (Stocks::isItemAvailable($itemid) == true){
                        $result = $this->db->query('UPDATE tbl_stocks SET qty = ? WHERE item_name = ?',array($hash_total,$hash_item));
                        header('location:'.SITE_URL.'StockReceive/m=added');
                    }else{
                        $result = $this->db->query('INSERT INTO tbl_stocks (item_name, qty, user)
                        VALUES (?, ?, ?)',array($hash_item, $hash_total, $hash_user));
                        header('location:'.SITE_URL.'StockReceive/m=added');
                    }
                break;

                case 1:
                    Stocks::StockIO($itemid,$qty,$user,$type);
                    $total = Stocks::getAvailableQuantities($itemid) + $qty;
                    $hash_item = $encrypt->sodiumStaticEncrypt($itemid);
                    $hash_total = $encrypt->sodiumStaticEncrypt($total);
                    $hash_user = $encrypt->sodiumStaticEncrypt($user);

                    if (Stocks::isItemAvailable($itemid) == true){
                        $result = $this->db->query('UPDATE tbl_stocks SET qty = ? WHERE item_name = ?',array($hash_total,$hash_item));
                        header('location:'.SITE_URL.'StockReceive/m=added');
                    }else{
                        $result = $this->db->query('INSERT INTO tbl_stocks (item_name, qty, user)
                        VALUES (?, ?, ?)',array($hash_item, $hash_total, $hash_user));
                        header('location:'.SITE_URL.'StockReceive/m=added');
                    }
                break;

                default:

                break;
            }
        }catch(PDOException $e){

        }
    }


    public function StockIO($itemid,$qty,$user,$type){
        try{
            $encrypt = new JustEncrypt();
            $hash_date = $encrypt->sodiumStaticEncrypt(date('r'));
            $result = $this->db->query('INSERT INTO tbl_stock_in (item_name, qty, user, type) 
            VALUES (?, ?, ?, ?)', array($itemid,$qty,$user,$type));
            $this->alert->SuccessAlert('Stock Item Added');
        }catch(PDOException $e){
            echo 'Failed to Insert Stock';
        }
    }


    public function isItemAvailable($itemid){
        $encrypt = new JustEncrypt();
        $hash_item_id = $encrypt->sodiumStaticEncrypt($itemid);
        $result = $this->db->query('SELECT * FROM tbl_stocks WHERE item_name = ?', array($hash_item_id));
        if (!empty($result)){
            return true;
        }
    }


    public function getAvailableQuantities($itemid){
        $encrypt = new JustEncrypt();
        $hash_item_id = $encrypt->sodiumStaticEncrypt($itemid);
        $result = $this->db->query('SELECT * FROM tbl_stocks WHERE item_name = ?', array($hash_item_id));
        if (!empty($result)){
            foreach ($result as $qty){
                return $encrypt->sodiumStaticDecrypt($qty['qty']);
            }
        }
    }


    public function getStockItems(){
        try{
            $encrypt = new JustEncrypt();
            $result = $this->db->query('SELECT * FROM tbl_stocks ORDER BY item_name ASC');
             echo '
            <table class="table table-striped">
                <tr>
                    <td>Item Name</td><td>Available Quantities</td>
                </tr>';
            if (!empty($result)){
                foreach($result as $stock){
                    echo '<tr>
                    <td><span class="moreinfo" data-toggle="tooltip" title="string stored in database: '.$stock['item_name'].'"> '.$encrypt->sodiumStaticDecrypt($stock['item_name']).'</span></td><td><span class="moreinfo" data-toggle="tooltip" title="string stored in database: '.$stock['qty'].'"> '.$encrypt->sodiumStaticDecrypt($stock['qty']).'</span></td>
                    </tr>';
                }
            }else{
                header('No Stock Items in Table.');
            }
        echo '
            </table>';
        }catch(PDOException $e){
            $alerts->ErrorAlert("Password Change Failed.");
        }
    }




}
?>
