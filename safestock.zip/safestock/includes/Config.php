<?php
ini_set('session.gc_maxlifetime', 7200);
session_set_cookie_params(7200);
session_start();
date_default_timezone_set('Africa/Harare');

$_POST = array_map('strip_tags', $_POST);
$_GET = array_map('strip_tags', $_GET);

error_reporting(E_ALL & ~E_STRICT & ~E_DEPRECATED & ~E_NOTICE & ~E_WARNING);
//error_reporting(E_ALL);
@ini_set('display_errors', 'On');
@ini_set('short_open_tag', false);

$HostName = $_SERVER["HTTP_HOST"].'/safestock';

// Define Database configuration details

define('SERVER', 'localhost');
define('DATABASE', 'dbstock');
define('DBUSER', 'root');
define('PASSWORD', '@lpha');

define('SITE_TITLE', 'Stock MAN');

// alias for DIRECTORY_SEPARATOR
define('DS', DIRECTORY_SEPARATOR);
    
// system base dir
define('BASE_DIR', realpath(dirname(__FILE__)).DS);
define('SITE_URL', 'http://'.$HostName);


spl_autoload_register(function($class) {
	$load = BASE_DIR.$class.'.php';
	if( file_exists($load) )
	{
		include_once($load);
	}
	else
	{
		die( "Can't find a file for class: $class - $load \n" );
	}
});
?>