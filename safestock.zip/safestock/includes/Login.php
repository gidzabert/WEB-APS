<?php

class Login{


    protected $db;
    protected $alert;

    public function setDB($db){
        $db = new DB();
        $alert = new Alerts();
        $this->db = $db;
        $this->alert = $alert;
    }
    
    public function ProcessLogin($uid,$pwd) {
        $encrypt = new JustEncrypt();

        if (empty($uid) or empty($pwd)){
            echo 'Username or Password is Empty';
        }else{
            $hash = $encrypt->sodiumStaticEncrypt($pwd);
            $result = $this->db->row('SELECT * FROM tbl_users WHERE email = ? AND password = ?',array($uid,$hash));
            if (!empty($result)){
                session_start();
                $_SESSION['uid'] = $result['email'];
                $_SESSION['name'] = $result['name'].' '.$result['surname'];
                $_SESSION['level'] = $result['level'];

                switch (trim($result['level'])){
                    case 1:
                        header('location:'.SITE_URL.'/StockAdmin');
                    break;
                    case 2:
                        header('location:'.SITE_URL.'/StockIssue');
                    break;
                    case 3:
                        header('location:'.SITE_URL.'/StockReceive');
                    break;

                    default:
                        $this->alert->ErrorAlert('Username or Password is incorrect');
                    break;
                }
            }else{
                header('location: CreateUser.php');
            }
            
        }
    }


    public function CreateUser($name,$surname,$email,$password){
        try{
            if (Login::isAccountAvailable($email) == true){
                $this->alert->ErrorAlert("Account is taken");
                exit();
            }
            $encrypt = new JustEncrypt();
            $hash = $encrypt->sodiumStaticEncrypt($password);
            if (Login::isAdminAvailable() == true){
                $level = 3;
            }else{
                $level = 1;
            }
            $result = $this->db->query('INSERT INTO tbl_users (name, surname, email, password, level) 
            VALUES (?, ?, ?, ?, ?)', array($name,$surname,$email,$hash,$level));
            $this->alert->SuccessAlert('User Account Created'.print_r($result).$level);
        }catch(PDOException $e){
            echo 'Failed to Create User';
        }
    }


    public function isAdminAvailable(){
        $level = 1;
        $result = $this->db->query('SELECT * FROM tbl_users WHERE level = ?', array($level));
        if (!empty($result)){
            return true;
        }
    }


    public function isAccountAvailable($email){
        $result = $this->db->query('SELECT * FROM tbl_users WHERE email = ?', array($email));
        if (!empty($result)){
            return true;
        }
    }


    public function UpdateLoginDate($uid){
        $date = date('r');
        $SQL = 'UPDATE tblusers SET last_login = ? WHERE uid = ?';
        $dbCon = new DB();
        $dbCon->query($SQL,array($date,$uid));
    }


    public function getUser($uid){
        $alerts = new Alerts;
        $SQL = 'SELECT * FROM tbl_system_users WHERE email = ?';
        $dbCon = new DB();
        $result = $dbCon->row($SQL,array($uid,$uid));
        if (!empty($result)){
            return $result['name'].' '.$result['surname'];
        }else{
            $SQL = 'SELECT * FROM tbl_app_users WHERE email = ?';
            $dbCon = new DB();
            $result = $dbCon->row($SQL,array($uid,$uid));
            if (!empty($result)){
                return $result['name'].' '.$result['surname'];
            }else{
                $alerts->ErrorAlert("User Does not Exist");
            }
        }
    }

    public function changeUserPassword($uid,$old,$new){
        try{
            $alerts = new Alerts;
            if (empty($uid) or empty($old) or empty($new)){
                parent::ErrorAlert('Required fields are Empty');
            }else{
                // Confirm the old password
                $hash_old = md5($old);
                $dbCon = new DB();
                $result = array();
                $result = $dbCon->row('SELECT * FROM tblusers WHERE uid = ? AND password = ?',array($uid,$hash_old));
                if (!empty($result)){
                    if ($result['password'] == $hash_old){
                        // proceed if the old passwords match
                        $hash_new = md5($new);
                        $result = $dbCon->row('UPDATE tblusers SET password = ? WHERE uid = ?',array($hash_new,$uid));
                        $alerts->SuccessAlert("Password Changed Successfully");
                    }else{
                        $alerts->ErrorAlert("Wrong Username or Password.");
                    }
                }else{
                    print_r($result);
                    $alerts->ErrorAlert("Error: Wrong Username or Password.");
                }
            }
        }catch(PDOException $e){
            $alerts->ErrorAlert("Password Change Failed.");
        }
    }




}
?>
