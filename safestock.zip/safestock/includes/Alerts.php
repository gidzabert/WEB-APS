<?php

class Alerts
{

    public function ErrorToast($title,$msg){
        echo '
        <div class="toast bg-light" role="alert" aria-live="assertive" aria-atomic="true" data-delay="10000">
            <div class="toast-header">
                <i class="fas fa-square text-danger"></i>
                <strong class="mr-auto">'.$title.'</strong>
                    <small>Just Now</small>
                <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="toast-body text-danger">
                '.$msg.'
            </div>
        </div>';
    }


    public function ErrorAlert($msg){
        echo'
        <div class="alert alert-danger alert-dismissible fade show" role="alert" data-autohide="true">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>'.$msg.'
        </div>';
    }


    public function SuccessAlert($msg){
        echo'
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>'.$msg.'
        </div>';
    }

    public function staticSuccessAlert($msg){
        echo'
        <div class="alert alert-success alert-dismissible fade show" role="alert">'.$msg.'</div>';
    }

    public function staticWarningAlert($msg){
        echo'
        <div class="alert alert-warning alert-dismissible fade show" role="alert">'.$msg.'</div>';
    }
    
    public function WarningAlert($msg){
        echo'
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>'.$msg.'
        </div>';
    }
}
?>
