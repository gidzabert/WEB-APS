<?php
/*
 *
 *
*/

class DB {

	protected $server;
	protected $port;
	protected $db;
	protected $password;
	protected $user;

	private $pdo;
	protected $sQuery;
	private $connectionStatus = false;
	private $logObject;
	private $parameters;
	public $rowCount = 0;
	public $columnCount = 0;
	public $querycount = 0;

  public function __construct(){
    $this->server = SERVER;
    $this->db = DATABASE;
    $this->port = DBPORT;
    $this->password = PASSWORD;
    $this->user = DBUSER;
    $this->parameters = array();
    $this->Connect();
  }

  protected function Connect(){
    try{
      $alerts = new Alerts();
      $dsn = 'mysql:';
			$dsn .= 'host=' . $this->server . ';';
			$dsn .= 'port=' . $this->port . ';';
			if (!empty($this->db)) {
				$dsn .= 'dbname=' . $this->db . ';';
			}
			$dsn .= 'charset=utf8;';
			$this->pdo = new PDO($dsn,
				$this->user, 
				$this->password,
				array(
					PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8",
					PDO::ATTR_EMULATE_PREPARES => false,
					PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
					PDO::MYSQL_ATTR_USE_BUFFERED_QUERY => true,
          PDO::MYSQL_ATTR_FOUND_ROWS => true
				)
			);
			  $this->connectionStatus = true;
		}
		catch (PDOException $e) {
			$alerts->ErrorAlert($e, '', 'Connect');
		}
  }

  /**
  * close pdo connection
  */
	public function closeConnection()
	{
		$this->pdo = null;
	}

  private function Init($query, $parameters = null, $driverOptions = array())
	{
		if (!$this->connectionStatus) {
			$this->Connect();
		}
		try {
			$this->parameters = $parameters;
			$this->sQuery     = $this->pdo->prepare($this->BuildParams($query, $this->parameters), $driverOptions);
			
			if (!empty($this->parameters)) {
				if (array_key_exists(0, $parameters)) {
					$parametersType = true;
					array_unshift($this->parameters, "");
					unset($this->parameters[0]);
				} else {
					$parametersType = false;
				}
				foreach ($this->parameters as $column => $value) {
					$this->sQuery->bindParam($parametersType ? intval($column) : ":" . $column, $this->parameters[$column]); //It would be query after loop end(before 'sQuery->execute()').It is wrong to use $value.
				}
			}

			if (!isset($driverOptions[PDO::ATTR_CURSOR])) {
                $this->sQuery->execute();
            }
			$this->querycount++;
		}
		catch (PDOException $e) {
      $alerts = new Alerts();
			$alerts->ErrorAlert($e, $this->BuildParams($query), 'Init', array('query' => $query, 'parameters' => $parameters));
		}
		
		$this->parameters = array();
	}
	
	private function BuildParams($query, $params = null)
	{
		if (!empty($params)) {
			$array_parameter_found = false;
			foreach ($params as $parameter_key => $parameter) {
				if (is_array($parameter)){
					$array_parameter_found = true;
					$in = "";
					foreach ($parameter as $key => $value){
						$name_placeholder = $parameter_key."_".$key;
						// concatenates params as named placeholders
					    	$in .= ":".$name_placeholder.", ";
						// adds each single parameter to $params
						$params[$name_placeholder] = $value;
					}
					$in = rtrim($in, ", ");
					$query = preg_replace("/:".$parameter_key."/", $in, $query);
					// removes array form $params
					unset($params[$parameter_key]);
				}
			}

			// updates $this->params if $params and $query have changed
			if ($array_parameter_found) $this->parameters = $params;
		}
		return $query;
	}

  /**
     * @return bool
     */
	public function beginTransaction()
	{
		return $this->pdo->beginTransaction();
	}

    /**
     * @return bool
     */
	public function commit()
	{
		return $this->pdo->commit();
	}

    /**
     * @return bool
     */
	public function rollBack()
	{
		return $this->pdo->rollBack();
	}

    /**
     * @return bool
     */
	public function inTransaction()
	{
		return $this->pdo->inTransaction();
	}

    /**
     * execute a sql query, returns an result array in the select operation, and returns the number of rows affected in other operations
     * @param string $query
     * @param null $params
     * @param int $fetchMode
     * @return array|int|null
     */
	public function query($query, $params = null, $fetchMode = PDO::FETCH_ASSOC)
	{
		$query = trim($query);
		$rawStatement = explode(" ", $query);
		$this->Init($query, $params);
		$statement = strtolower($rawStatement[0]);
		if ($statement === 'select' || $statement === 'show' || $statement === 'call' || $statement === 'describe') {
			return $this->sQuery->fetchAll($fetchMode);
		} elseif ($statement === 'insert' || $statement === 'update' || $statement === 'delete') {
			return $this->sQuery->rowCount();
		} else {
			return NULL;
		}
	}

   /**
     * @param $tableName
     * @param null $params
     * @return bool|string
     */
	public function insert($tableName, $params = null)
	{
		$keys = array_keys($params);
		$rowCount = $this->query(
			'INSERT INTO `' . $tableName . '` (`' . implode('`,`', $keys) . '`) 
			VALUES (:' . implode(',:', $keys) . ')',
			$params
		);
		if ($rowCount === 0) {
			return false;
		}
		return $this->lastInsertId();
	}

    /**
     * @return string
     */
	public function lastInsertId()
	{
		return $this->pdo->lastInsertId();
	}


    /**
     * @param $query
     * @param null $params
     * @return array
     */
	public function column($query, $params = null)
	{
		$this->Init($query, $params);
		$resultColumn = $this->sQuery->fetchAll(PDO::FETCH_COLUMN);
		$this->rowCount = $this->sQuery->rowCount();
		$this->columnCount = $this->sQuery->columnCount();
		$this->sQuery->closeCursor();
		return $resultColumn;
	}

    /**
     * @param $query
     * @param null $params
     * @param int $fetchmode
     * @return mixed
     */
	public function row($query, $params = null, $fetchmode = PDO::FETCH_ASSOC)
	{
		$this->Init($query, $params);
		$resultRow = $this->sQuery->fetch($fetchmode);
		$this->rowCount = $this->sQuery->rowCount();
		$this->columnCount = $this->sQuery->columnCount();
		$this->sQuery->closeCursor();
		return $resultRow;
	}

    /**
     * @param $query
     * @param null $params
     * @return mixed
     */
	public function single($query, $params = null)
	{
		$this->Init($query, $params);
		return $this->sQuery->fetchColumn();
	}
  

}
