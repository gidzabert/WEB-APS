<?php 
require_once("../includes/Config.php");
$login = new Login();
$stocks = new Stocks();
$db = $stocks->setDB($db);
$listitems = $stocks->getStockItems();
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title><?php echo SITE_URL; ?></title>

  <!-- Bootstrap core CSS -->
  <link href="<?php echo SITE_URL;?>/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/simple-sidebar.css" rel="stylesheet">

</head>

<body>

      <nav class="navbar navbar-expand-lg navbar-light bg-dark border-bottom">
        <button class="btn btn-primary" id="menu-toggle">Toggle Menu</button>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <?php echo $_SESSION['name'];?>
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="#">Change Password</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#">logout</a>
              </div>
            </li>
          </ul>
        </div>
      </nav>

  <div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading m-2">Safe Stock </div>
      <div class="list-group list-group-flush">
        <a href="../StockAdmin" class="list-group-item list-group-item-action bg-light">Dashboard</a>
        <a href="Stock.php" class="list-group-item list-group-item-action bg-light">Stock</a>
        <a href="Users.php" class="list-group-item list-group-item-action bg-light">Users</a>
      </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">

      <div class="container-fluid">
        <h1 class="mt-4">Stock Items</h1>
        <div class="row">
          <div class="col-md-12">
            <div class="panel panel-default">
              <!-- /.panel-heading -->
              <div class="panel-body">
                <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-table">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Item Name</th>
                    <th>Item Description</th>
                    <th>Item Code</th>
                    <th>Quantities</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                        					if (is_array($listItems)) {
                                    $i = 0;
                        						foreach($listItems as $row) {
                                      $i++;
                                      if ($i % 2 == 0) {$rowClass = "even";} else {$rowClass = "odd";}
                        							?>
                                  <tr class="<?php echo $rowClass;?> gradeX">
                                      <td><?php echo $row['id']?></td>
                                      <td><?php echo $row['first_name'];?></td>
                                      <td><?php echo $row['last_name']?></td>
                                      <td><span class="moreinfo" data-toggle="tooltip" title="string stored in database: <?php echo $row['email'];?>"><?php echo $dao->dec($row['email']);?></span></td>
                                      <td><span class="moreinfo" data-toggle="tooltip" title="string stored in database: <?php echo $row['phone'];?>"><?php echo $dao->dec($row['phone']);?></span></td>
                                      <td><?php echo $row['creation_date']?></td>
                                      <td><?php echo $row['source']?></td>                           
                                      <td><?php echo $row['privacy']?></td>
                                  </tr>
                                <?php }
                                    }
                                ?>
                                </tbody>
                            </table>

                            <div class="paging">
			                    <?php //echo paging($_GET["page"],$start,$end,$countItems[0]["c"]);?>
		                    </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
          </div>
        </div>
      </div>
    </div>
    <!-- /#page-content-wrapper -->

  </div>
  <!-- /#wrapper -->

  <!-- Bootstrap core JavaScript -->
  <script src="<?php echo SITE_URL;?>/assets/vendor/jquery/jquery.min.js"></script>
  <script src="<?php echo SITE_URL;?>/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Menu Toggle Script -->
  <script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
  </script>

</body>

</html>
